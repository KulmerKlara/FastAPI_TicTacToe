import pytest
from app.models.game import Game
from app.models.user import User

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.db.base import Base


@pytest.fixture
async def db_session():
    engine = create_engine("sqlite:///:memory:", echo=False)

    Base.metadata.create_all(engine)

    Session = sessionmaker(bind=engine)
    session = Session()

    yield session

    session.close()
    Base.metadata.drop_all(engine)



@pytest.mark.asyncio
async def test_game_relationships(db_session):
    user_x = User(username="x")
    user_o = User(username="o")

    db_session.add_all([user_x, user_o])
    await db_session.commit()

    game = Game(
        player_x_id=user_x.id,
        player_o_id=user_o.id
    )

    db_session.add(game)
    await db_session.commit()
    await db_session.refresh(game)

    assert game.player_x.username == "x"
    assert game.player_o.username == "o"